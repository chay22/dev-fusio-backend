
## File

Path to a simple static json file. Fusio will simply forward the content to
the client. This is helpful if you want to build fast an sample API with dummy 
responses.

### Example

```
/tmp/static.json
```
