
## User

A user is either a `Consumer` which uses the API or an `Administrator` which 
manages the API through the backend. An Administrator account can request an 
access token for the backend API. Fusio has a simple consumer app located
at `/developer` where a user can manage all app settings.
